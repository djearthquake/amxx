  AMX Gravity Gun Deathmatch


  Version: 0.3.1
  Author: KRoTaL

  0.1   Release
  0.1.1 Bug fixes
  0.2   Now works like the real HL2 gravity gun with the real sounds :)
  0.2.1 Added Gauss gun model
  0.2.2 Bug fixes
  0.3   Added 2 new settings: ggdm_allweapons + ggdm_damage, + the possibility to grab and throw players
  0.3.1 Fewer objects should stay in the air


  Objects will be randomly created on the map (you can configure the models to be used).
  Grab them and throw them at your ennemies to kill them, or throw them directly if you are close to them.
  You cannot use any other weapons.
  To grab an object/player, press the +attack2 button.
  To throw an object/player, press the +attack button.

  IMPORTANT: If your server crashes, try reducing the ggdm_objects setting (especially on small maps).


  Cvars:

  ggdm_active 0   - 0: disables the plugin
                    1: enables the plugin (objects will be created next round)

  ggdm_allweapons 0 - 0: players can only use the gravity gun
                      1: players can use all the weapons, and the knife is replaced with the gravity gun

  ggdm_damage 20    - amount of damage done to a player when you throw him

  ggdm_grabforce 10 - sets the amount of force used when grabbing objects

  ggdm_throwforce 1400  - sets the power of your throws

  ggdm_objects 30   - sets how many objects to create on the map (between 1 and 80)

  ggdm_maxdist 140  - sets how close to an object you need to be to throw it without grabbing it

  ggdm_maxdist_grab 1500  - sets how close to an object you need to be to grab it


  Setup:

  Put these files on your server:

  addons/amx/plugins/gravitygun_dm.amx
  addons/amx/lang/ggdm.txt
  addons/amx/config/ggdm_objects.cfg
  sound/ggdm/ggdm_throw.mp3
  sound/ggdm/ggdm_grab.mp3
  sound/ggdm/ggdm_grabbing.mp3
  sound/ggdm/ggdm_denythrow.mp3
  sound/ggdm/ggdm_denygrab.mp3

  You can configure the models to be used for the objects in the ggdm_objects.cfg file.
  Format:

  path_of_the_model name_of_the_model MinBox(X_axis) MinBox(Y_axis) MinBox(Z_axis) MaxBox(X_axis) MaxBox(Y_axis) MaxBox(Z_axis)

  Examples:

  models/chick.mdl chicken -20 -20 -1 20 20 20
  models/w_weaponbox.mdl weaponbox -12 -12 -1 12 12 40
  models/filecabinet.mdl filecabinet -16 -16 -1 16 16 60
  models/houndeye.mdl houndeye -20 -20 -1 20 20 25
  models/w_flashbang.mdl flashbang -10 -10 -1 10 10 10
  models/w_smokegrenade.mdl smokegrenade -10 -10 -1 10 10 10
  models/w_hegrenade.mdl grenade -10 -10 -1 10 10 10

  The name of the model will be used in the death messages:
  KRoT@L killed T(+)rget with washbasin
  KRoT@L killed T(+)rget with chicken

  If you want to type a space in the name of the model, use quotes:
  models/big_thing.mdl "big thing" -20 -20 -20 20 20 20

  Do not forget to put the models on your server to allow people to download them.

  You need to enable VexdUM.

  Credits:
  SpaceDude for his Jedi Grab Plugin
  Kaddar for his Rune Mod Plugin
